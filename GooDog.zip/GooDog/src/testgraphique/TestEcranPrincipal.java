package testgraphique;

import vuegraphique.FramePrincipal;

public class TestEcranPrincipal {

	public static void main(String[] args) {
		new FramePrincipal(1920,1080); //permet de choisir directement la taille de la fenetre
	}
}
