package model;

public enum Couleur {
	BLANC,
	NOIR,
	ROUGE,
	VERT,
	BLEU
	
}
