package model;

public class Indexeur {

	public boolean indexerImage() {
		// TODO Auto-generated method stub
		return true;
	}

	public boolean indexerSon() {
		// TODO Auto-generated method stub
		return true;
	}

	public boolean indexerTexte() {
		// TODO Auto-generated method stub
		return true;
	}
		
}
