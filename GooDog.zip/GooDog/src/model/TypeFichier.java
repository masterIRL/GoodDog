package model;

public enum TypeFichier {
	IMAGE,
	SON,
	TEXTE

}
