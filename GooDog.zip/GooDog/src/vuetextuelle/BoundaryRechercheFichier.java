package vuetextuelle;

import java.util.List;

import control.ControlRecherche;
import model.TypeFichier;

public class BoundaryRechercheFichier {

	private ControlRecherche controlRecherche;
	
	public BoundaryRechercheFichier(ControlRecherche controlRecherche) {
		this.controlRecherche = controlRecherche;
	}

	public void rechercheFichier() {
		int choix = 0;
		Clavier clavier = new Clavier();
		while(!(choix == 1 || choix == 2 || choix == 3)) {
			System.out.println("1. Recherche fichier texte\n" + "2. Recherche fichier son\n" + "3. Recherche fichier image");
			choix = clavier.entrerClavierInt();	
			if(!(choix==1 || choix==2 || choix==3)) {
				System.out.println("Veuillez entrer 1, 2 ou 3");
			}
		}
		
		System.out.println("Veuillez entrer le nom ou le chemin du fichier");
		String nom = clavier.entrerClavierString();
		
		int seuil = -1;
		while(seuil < 0 || seuil > 100) {
			System.out.println("Veuillez donner le seuil de similarit� (en %):");
			seuil = clavier.entrerClavierInt();
			if(seuil < 0 || seuil > 100) {
				System.out.println("Seuil compris entre 0 et 100 (en %)");
			}
		}
		
		System.out.println("Resulat de la requette: '" + nom + "'		similaire � " + seuil + "% :");

		String resultat = new String();
		switch (choix) {
		case 1:
			List<String> listeTexte = controlRecherche.rechercheFichier(TypeFichier.TEXTE,nom,seuil);
			if(listeTexte != null) {
				int i = 1;
				for (String string : listeTexte) {
					resultat += i + " : " + string + "\n";
					i++;
				}
			}
			else
				System.out.println("Aucun r�sultat");
			break;
			
		case 2:
			List<String> listeSon = controlRecherche.rechercheFichier(TypeFichier.SON,nom,seuil);
			if(listeSon != null) {
				int i = 1;
				for (String string : listeSon) {
					resultat += i + " : " + string;
					i++;
				}
			}
			else
				System.out.println("Aucun r�sultat");
			
			break;
			
		case 3:
			List<String> listeImage = controlRecherche.rechercheFichier(TypeFichier.IMAGE,nom,seuil);
			if(listeImage != null) {
				int i = 1;
				for (String string : listeImage) {
					resultat += i + " : " + string;
					i++;
				}
			}
			else
				System.out.println("Aucun r�sultat");
			
			break;
			
		default:
			System.out.println("Type de recherche fichier non reconnu");
			break;
		}
		System.out.println(resultat);
	}
}
