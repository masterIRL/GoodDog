package testtextuel;

import java.util.HashMap;
import java.util.Map;

public class testCasIndexation {

}
