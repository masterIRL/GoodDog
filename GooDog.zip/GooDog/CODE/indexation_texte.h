//======================================================================//
// Indexation texte
//======================================================================//


#ifndef INDEX_DESCRIPTEUR_TXT_H
#define INDEX_DESCRIPTEUR_TXT_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "descripteur_texte.h"
#include"file_descript_texte.h"

int indexation_texte (char*chemin);

#endif

